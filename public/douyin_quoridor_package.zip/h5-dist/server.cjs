var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// server.ts
var server_exports = {};
module.exports = __toCommonJS(server_exports);
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_vite = require("vite");

// src/game/rules.ts
var INITIAL_WALLS_COUNT = {
  2: 10,
  3: 7,
  4: 5
};
function getInitialPositions(playerCount) {
  if (playerCount === 2) {
    return [{ x: 4, y: 8 }, { x: 4, y: 0 }];
  }
  if (playerCount === 3) {
    return [{ x: 4, y: 8 }, { x: 8, y: 4 }, { x: 4, y: 0 }];
  }
  return [{ x: 4, y: 8 }, { x: 8, y: 4 }, { x: 4, y: 0 }, { x: 0, y: 4 }];
}
function isGoalReached(playerId, playerCount, x, y) {
  if (playerCount === 2) {
    return playerId === 0 ? y === 0 : y === 8;
  }
  if (playerCount === 3) {
    if (playerId === 0) return y === 0;
    if (playerId === 1) return x === 0;
    return y === 8;
  }
  if (playerId === 0) return y === 0;
  if (playerId === 1) return x === 0;
  if (playerId === 2) return y === 8;
  if (playerId === 3) return x === 8;
  return false;
}
function formatCoordinate(pos) {
  const col = String.fromCharCode(65 + pos.x);
  const row = (pos.y + 1).toString();
  return `${col}${row}`;
}
function formatActionNotation(action) {
  if (action.type === "MOVE") {
    return `Move -> ${formatCoordinate({ x: action.x, y: action.y })}`;
  }
  const grooveCol = String.fromCharCode(97 + action.x);
  const grooveRow = (action.y + 1).toString();
  return action.d === 0 ? `H-Wall(${grooveCol}${grooveRow})` : `V-Wall(${grooveCol}${grooveRow})`;
}
function createInitialState(playerCount, firstId = 0) {
  const initialPositions = getInitialPositions(playerCount);
  const initialWallCount = INITIAL_WALLS_COUNT[playerCount];
  return {
    playerCount,
    playerPos: initialPositions,
    walls: [],
    leftWalls: new Array(playerCount).fill(initialWallCount),
    waitFor: firstId,
    firstId,
    round: 1,
    winnerId: [],
    winnerRound: [],
    isOver: false,
    history: [],
    recordList: []
  };
}
function applyAction(state, action) {
  if (state.isOver) return state;
  const currentP = state.waitFor;
  const newPositions = state.playerPos.map((p) => ({ ...p }));
  const newWalls = [...state.walls];
  const newLeftWalls = [...state.leftWalls];
  const newWinnerId = [...state.winnerId];
  const newWinnerRound = [...state.winnerRound];
  if (action.type === "MOVE") {
    newPositions[currentP] = { x: action.x, y: action.y };
    if (!newWinnerId.includes(currentP) && isGoalReached(currentP, state.playerCount, action.x, action.y)) {
      newWinnerId.push(currentP);
      newWinnerRound.push(state.round);
    }
  } else {
    newWalls.push({ x: action.x, y: action.y, d: action.d, p: currentP });
    newLeftWalls[currentP] = Math.max(0, newLeftWalls[currentP] - 1);
  }
  let nextPlayer = currentP;
  let nextRound = state.round;
  let isGameOver = false;
  if (newWinnerId.length > 0) {
    isGameOver = true;
  } else {
    for (let step = 0; step < state.playerCount; step++) {
      nextPlayer = (nextPlayer + 1) % state.playerCount;
      if (nextPlayer === state.firstId) {
        nextRound += 1;
      }
      if (!newWinnerId.includes(nextPlayer)) {
        break;
      }
    }
  }
  const notation = formatActionNotation(action);
  const record = {
    round: state.round,
    playerId: currentP,
    action,
    notation,
    timestamp: Date.now()
  };
  const snapshotState = {
    playerCount: state.playerCount,
    playerPos: state.playerPos,
    walls: state.walls,
    leftWalls: state.leftWalls,
    waitFor: state.waitFor,
    firstId: state.firstId,
    round: state.round,
    winnerId: state.winnerId,
    winnerRound: state.winnerRound,
    isOver: state.isOver,
    recordList: state.recordList
  };
  return {
    playerCount: state.playerCount,
    playerPos: newPositions,
    walls: newWalls,
    leftWalls: newLeftWalls,
    waitFor: nextPlayer,
    firstId: state.firstId,
    round: nextRound,
    winnerId: newWinnerId,
    winnerRound: newWinnerRound,
    isOver: isGameOver,
    history: [...state.history, { state: snapshotState, action, notation }],
    recordList: [...state.recordList, record]
  };
}

// server.ts
var PORT = 3e3;
var app = (0, import_express.default)();
app.use(import_express.default.json());
var rooms = /* @__PURE__ */ new Map();
var roomSubscribers = /* @__PURE__ */ new Map();
var DEFAULT_SLOT_AVATARS = ["\u{1F431}", "\u{1F436}", "\u{1F434}", "\u{1F42E}"];
var DEFAULT_SLOT_NAMES = ["\u5C0F\u732B", "\u5C0F\u72D7", "\u5C0F\u9A6C", "\u5C0F\u725B"];
function generateRoomId() {
  const chars = "23456789abcdefghjkmnpqrstuvwxyz";
  let result = "";
  for (let i = 0; i < 4; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}
function broadcastRoomUpdate(roomId, room) {
  const subs = roomSubscribers.get(roomId);
  if (subs && subs.size > 0) {
    const payload = `data: ${JSON.stringify(room ? { type: "ROOM_UPDATE", room } : { type: "ROOM_DISBANDED" })}

`;
    for (const clientRes of Array.from(subs)) {
      try {
        clientRes.write(payload);
      } catch {
        subs.delete(clientRes);
      }
    }
  }
}
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", activeRooms: rooms.size });
});
app.post("/api/rooms", (req, res) => {
  const playerCount = req.body.playerCount || 2;
  const hostName = req.body.hostName || "\u5C0F\u732B (\u623F\u4E3B)";
  const hostAvatar = req.body.hostAvatar || "\u{1F431}";
  const playerId = req.body.playerId || "user_" + Math.random().toString(36).substring(2, 9);
  let roomId = generateRoomId();
  while (rooms.has(roomId)) {
    roomId = generateRoomId();
  }
  const initialState = createInitialState(playerCount);
  const newRoom = {
    id: roomId,
    createdAt: Date.now(),
    hostId: playerId,
    playerCount,
    players: [
      {
        id: playerId,
        name: hostName,
        avatar: hostAvatar,
        playerIndex: 0,
        isHost: true,
        connected: true
      }
    ],
    state: initialState,
    status: "waiting"
  };
  rooms.set(roomId, newRoom);
  broadcastRoomUpdate(roomId, newRoom);
  res.json({ room: newRoom, playerIndex: 0 });
});
app.get("/api/rooms/:id", (req, res) => {
  const roomId = req.params.id.trim().toLowerCase();
  const room = rooms.get(roomId);
  if (!room) {
    return res.status(404).json({ error: "\u623F\u95F4\u4E0D\u5B58\u5728\u6216\u5DF2\u89E3\u6563" });
  }
  res.json({ room });
});
app.post("/api/rooms/:id/join", (req, res) => {
  const roomId = req.params.id.trim().toLowerCase();
  const room = rooms.get(roomId);
  if (!room) {
    return res.status(404).json({ error: "\u672A\u627E\u5230\u8BE5\u623F\u95F4\uFF0C\u8BF7\u786E\u8BA4\u623F\u95F4\u53F7\u662F\u5426\u8F93\u5165\u6B63\u786E" });
  }
  const playerId = req.body.playerId || "user_" + Math.random().toString(36).substring(2, 9);
  const existingPlayer = room.players.find((p) => p.id === playerId);
  if (existingPlayer) {
    return res.json({ room, playerIndex: existingPlayer.playerIndex });
  }
  if (room.players.length >= room.playerCount) {
    return res.status(400).json({ error: "\u8BE5\u623F\u95F4\u73A9\u5BB6\u4EBA\u6570\u5DF2\u6EE1\uFF0C\u65E0\u6CD5\u52A0\u5165" });
  }
  const nextIdx = room.players.length;
  const newPlayer = {
    id: playerId,
    name: req.body.playerName || DEFAULT_SLOT_NAMES[nextIdx] || `\u73A9\u5BB6${nextIdx + 1}`,
    avatar: req.body.playerAvatar || DEFAULT_SLOT_AVATARS[nextIdx] || "\u{1F436}",
    playerIndex: nextIdx,
    isHost: false,
    connected: true
  };
  room.players.push(newPlayer);
  broadcastRoomUpdate(roomId, room);
  res.json({ room, playerIndex: nextIdx });
});
app.post("/api/rooms/:id/start", (req, res) => {
  const roomId = req.params.id.trim().toLowerCase();
  const room = rooms.get(roomId);
  if (!room) {
    return res.status(404).json({ error: "\u623F\u95F4\u4E0D\u5B58\u5728" });
  }
  if (req.body.fillWithAi) {
    while (room.players.length < room.playerCount) {
      const idx = room.players.length;
      room.players.push({
        id: `ai_${idx}_${Math.random().toString(36).substring(2, 7)}`,
        name: `${DEFAULT_SLOT_NAMES[idx] || "\u73A9\u5BB6"} (AI)`,
        avatar: DEFAULT_SLOT_AVATARS[idx] || "\u{1F916}",
        playerIndex: idx,
        isHost: false,
        connected: true
      });
    }
  }
  room.status = "playing";
  room.state = createInitialState(room.playerCount);
  broadcastRoomUpdate(roomId, room);
  res.json({ room });
});
app.post("/api/rooms/:id/action", (req, res) => {
  const roomId = req.params.id.trim().toLowerCase();
  const room = rooms.get(roomId);
  if (!room) {
    return res.status(404).json({ error: "\u623F\u95F4\u4E0D\u5B58\u5728" });
  }
  const action = req.body.action;
  if (!action) {
    return res.status(400).json({ error: "\u7F3A\u5C11\u64CD\u4F5C\u5185\u5BB9" });
  }
  const nextState = applyAction(room.state, action);
  room.state = nextState;
  if (nextState.isOver) {
    room.status = "finished";
  }
  broadcastRoomUpdate(roomId, room);
  res.json({ room });
});
app.post("/api/rooms/:id/reset", (req, res) => {
  const roomId = req.params.id.trim().toLowerCase();
  const room = rooms.get(roomId);
  if (!room) {
    return res.status(404).json({ error: "\u623F\u95F4\u4E0D\u5B58\u5728" });
  }
  room.state = createInitialState(room.playerCount);
  room.status = "playing";
  broadcastRoomUpdate(roomId, room);
  res.json({ room });
});
app.post("/api/rooms/:id/leave", (req, res) => {
  const roomId = req.params.id.trim().toLowerCase();
  const room = rooms.get(roomId);
  if (!room) {
    return res.json({ disbanded: true });
  }
  const playerId = req.body.playerId;
  if (room.hostId === playerId) {
    rooms.delete(roomId);
    broadcastRoomUpdate(roomId, null);
    return res.json({ disbanded: true });
  } else {
    room.players = room.players.filter((p) => p.id !== playerId);
    room.players.forEach((p, idx) => {
      p.playerIndex = idx;
    });
    broadcastRoomUpdate(roomId, room);
    return res.json({ disbanded: false, room });
  }
});
app.get("/api/rooms/:id/events", (req, res) => {
  const roomId = req.params.id.trim().toLowerCase();
  const room = rooms.get(roomId);
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders?.();
  if (!roomSubscribers.has(roomId)) {
    roomSubscribers.set(roomId, /* @__PURE__ */ new Set());
  }
  const subs = roomSubscribers.get(roomId);
  subs.add(res);
  if (room) {
    res.write(`data: ${JSON.stringify({ type: "ROOM_UPDATE", room })}

`);
  } else {
    res.write(`data: ${JSON.stringify({ type: "ROOM_DISBANDED" })}

`);
  }
  const heartbeat = setInterval(() => {
    try {
      res.write(": ping\n\n");
    } catch {
      clearInterval(heartbeat);
      subs.delete(res);
    }
  }, 15e3);
  req.on("close", () => {
    clearInterval(heartbeat);
    subs.delete(res);
  });
});
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Quoridor server running on http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
